url_to_check = 'http://localhost:3001/browse/'
time_interval = 45 				# in seconds
time_interval_on_failure = 180  # in seconds